﻿using System.Collections.Generic;

namespace VelcroPhysics.ContentPipelines.SVGImport.Objects
{
    public class VerticesContainer : Dictionary<string, List<VerticesExt>>
    {
        public VerticesContainer()
        {
            
        }
    }
}
