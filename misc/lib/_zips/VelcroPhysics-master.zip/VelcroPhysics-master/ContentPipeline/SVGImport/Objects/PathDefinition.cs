﻿using Microsoft.Xna.Framework;

namespace VelcroPhysics.ContentPipelines.SVGImport.Objects
{
    public class PathDefinition
    {
        public string Path;
        public string Id;
        public Matrix Transformation;
    }
}