﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("VelcroPhysics.ContentPipeline.SVGImport")]