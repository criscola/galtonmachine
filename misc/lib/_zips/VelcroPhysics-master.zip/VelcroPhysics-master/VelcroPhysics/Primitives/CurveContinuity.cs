namespace Microsoft.Xna.Framework
{
    public enum CurveContinuity
    {
        Smooth,
        Step
    }
}