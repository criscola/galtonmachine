namespace VelcroPhysics.Collision.Narrowphase
{
    public enum EPAxisType
    {
        Unknown,
        EdgeA,
        EdgeB
    }
}