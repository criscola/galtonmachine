namespace VelcroPhysics.Collision.Narrowphase
{
    public enum ManifoldType
    {
        Circles,
        FaceA,
        FaceB
    }
}