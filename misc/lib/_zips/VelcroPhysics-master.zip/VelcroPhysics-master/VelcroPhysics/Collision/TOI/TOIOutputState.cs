namespace VelcroPhysics.Collision.TOI
{
    public enum TOIOutputState
    {
        Unknown,
        Failed,
        Overlapped,
        Touching,
        Seperated
    }
}