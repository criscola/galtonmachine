namespace VelcroPhysics.Collision.TOI
{
    public enum SeparationFunctionType
    {
        Points,
        FaceA,
        FaceB
    }
}