using VelcroPhysics.Dynamics;

namespace VelcroPhysics.Collision.Handlers
{
    public delegate bool BeforeCollisionHandler(Fixture fixtureA, Fixture fixtureB);
}