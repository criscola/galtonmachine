namespace VelcroPhysics.Templates
{
    public interface IDefaults
    {
        void SetDefaults();
    }
}