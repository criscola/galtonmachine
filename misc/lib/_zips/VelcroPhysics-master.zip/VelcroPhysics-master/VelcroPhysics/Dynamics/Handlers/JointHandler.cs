using VelcroPhysics.Dynamics.Joints;

namespace VelcroPhysics.Dynamics.Handlers
{
    public delegate void JointHandler(Joint joint);
}