namespace VelcroPhysics.Dynamics.Handlers
{
    public delegate void FixtureHandler(Fixture fixture);
}