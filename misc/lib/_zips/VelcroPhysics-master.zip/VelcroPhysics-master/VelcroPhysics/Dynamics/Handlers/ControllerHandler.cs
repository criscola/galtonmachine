using VelcroPhysics.Extensions.Controllers.ControllerBase;

namespace VelcroPhysics.Dynamics.Handlers
{
    public delegate void ControllerHandler(Controller controller);
}