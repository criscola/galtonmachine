namespace VelcroPhysics.Dynamics.Joints
{
    public enum LimitState
    {
        Inactive,
        AtLower,
        AtUpper,
        Equal
    }
}