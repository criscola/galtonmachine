using System;

namespace VelcroPhysics.Extensions.PhysicsLogics.PhysicsLogicBase
{
    [Flags]
    public enum PhysicsLogicType
    {
        Explosion = 1 << 0
    }
}