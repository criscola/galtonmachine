namespace VelcroPhysics.Extensions.Controllers.Gravity
{
    public enum GravityType
    {
        Linear,
        DistanceSquared
    }
}