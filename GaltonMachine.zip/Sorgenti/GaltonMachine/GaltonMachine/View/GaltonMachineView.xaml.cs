﻿using System.Windows.Controls;

namespace GaltonMachine.View
{
    /// <summary>
    /// Interaction logic for GaltonMachineView.xaml
    /// </summary>
    public partial class GaltonMachineView : UserControl
    {
        public GaltonMachineView()
        {
            InitializeComponent();
        }
    }
}
