##Diario Galton Machine Project

####Data : 27 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Creato un nuovo progetto in JavaFX e creata rappresentazione dinamica della piramide di cerchi

##Problemi riscontrati e soluzioni adottate

- Ho avuto vari problemi con C# che mi hanno portato a cambiare su Java. Ho constatato il pattern MVVM è esagerato per mettere in funzione solo un paio di controlli ed è alquanto una perdita di tempo ed energia stargli dietro, inoltre conosco molto meglio Java.

##Punto di situazione del lavoro

Leggermente indietro 


##Programma per la prossima volta

- Continuare a lavorare sul codice grafico, creare le animazioni, aggiungere i controlli, farlo responsive.