## Diario Galton Machine Project

#### Data : 21 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Terminato progetto e documentazione
- Risolto problema dell'overflow. La funzione per la generazione della curva generava NaN quando c'erano divisioni per zero, ho aggiunto un controllo per evitare questo.

## Problemi riscontrati e soluzioni
\-
## Punto di situazione del lavoro

\-

## Programma per la prossima volta

\-