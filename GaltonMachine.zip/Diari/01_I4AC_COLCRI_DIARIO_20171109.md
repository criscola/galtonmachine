##Diario Galton Machine Project

####Data : 8 novembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Continuato sistema di disegno istogrammi

##Problemi riscontrati e soluzioni

- Sto riscontrando un problema con le etichette degli istogrammi, non si aggiorna il testo
- Risolto problema dell'ultima volta riguardante il grafico che non mostrava nulla, al momento dell'aggiunta delle ObservableCollection avrei dovuto prima inserire le collection in una CompositeContainer e poi aggiungerle alla CompositeCollection
- Mi sono accorto che c'è qualche problema con la griglia delle palline, ho avuto una exception quando la pallina è arrivata all'angolo in basso a destra e pare che la pallina non arrivi mai all'angolo in basso a sinistra, dovrei investigare 

##Punto di situazione del lavoro

Indietro. Da finire assolutamente il grafico entro 1-2 settimane.

##Programma per la prossima volta

Risolvere il problema all'etichetta, aggiungere curva normale