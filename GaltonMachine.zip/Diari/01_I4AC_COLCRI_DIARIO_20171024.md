##Diario Galton Machine Project

####Data : 24 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Modificato layout per accomodare il futuro diagramma
- Scaricato un codice già fatto per il disegno della curva normale, poi l'ho modificato per funzionare con un set di dati e ho iniziato a metterci mano per integrarlo nel futuro canvas del grafico in WPF (il progetto già fatto è in winforms)
- Iniziato a scrivere le classi per gli istogrammi futuri

##Problemi riscontrati e soluzioni adottate

Nessun problema

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

- Finire il textblock nella GUI, continuare gli istogrammi