##Diario Galton Machine Project

####Data : 29 agosto 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Scelta progetto
- Analisi del background del progetto (visione video su youtube che spiegano la macchina di Galton, il teorema del limite centrale e distribuzione normale, il gioco del pachinko)
- Analisi pratica del codice (librerie da usare, template MVVM da utilizzare)
- Iniziata stesura del diagramma di Gantt
- Creata repository su GitHub

##Problemi riscontrati e soluzioni adottate

-

##Punto di situazione del lavoro

-

##Programma per la prossima settimana

- Finire stesura diagramma di Gantt
- Continuare analisi e progettazione del progetto
- Iniziare stesura documentazione