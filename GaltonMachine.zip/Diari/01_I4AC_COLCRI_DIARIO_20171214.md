## Diario Galton Machine Project

#### Data : 14 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Sistemato disegno curva
- Aggiunte etichette che mostrano media, varianza e standard deviation
- Ampliata progettazione

## Problemi riscontrati e soluzioni

Il problema dell'altra volta era semplicemente perchè dovevo fare un Freeze() sull'immagine e fare l'assegnazione nel Dispatcher.
Questa volta ho un problema che non riesco a capire da dove arriva, una StackOverflowException che si verifica in momenti apparentemente casuali dell'esecuzione del programma.
## Punto di situazione del lavoro

Indietro con la doc 

## Programma per la prossima volta

Sistemare dettagli grafici e continuare documentazione implementazione