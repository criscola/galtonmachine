##Diario Galton Machine Project

####Data : 14 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Continuata documentazione implementazione/diagramma di flusso
- Creata la prima demo, un'applicazione console in modo da testare la logica del programma e creare una piccola simulazione da esempio (progetto src/GaltonConsole)

##Problemi riscontrati e soluzioni adottate

-

##Punto di situazione del lavoro

In linea

##Programma per la prossima volta

- Implementare il progetto console in MVVM/WPF utilizzando grafica e costrutti del pattern, continuare un po' a documentare l'implementazione