## Diario Galton Machine Project

#### Data : 11 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

Sono stato presente solo le prime 2 ore del mattino

- Refactoring codice
Ho rimesso la pallina singola, modifiche minori al codice.

## Problemi riscontrati e soluzioni

nessuno

## Punto di situazione del lavoro

Indietro con la doc sopratutto

## Programma per la prossima volta

Continuare riscrittura codice