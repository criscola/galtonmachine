##Diario Galton Machine Project

####Data : 17 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Aggiornata/corretta documentazione e migliorata impaginazione
- Sistemata grafica 
- Finiti i comandi di base Start, Reset, About e Close
- Refactoring codice

##Problemi riscontrati e soluzioni adottate

Nessun problema

##Punto di situazione del lavoro

In linea

##Programma per la prossima volta

- Aggiungere comandi slider velocità simulazione e n° di simulazioni possibili. Continuare documentazione, continuare analisi grafici, iniziare a stendere la struttura grafica per i grafici
- Mettere apposto il Canvas della pallina, deve essere esattamente sopra il canvas delle stecche, o ridimensionando la finestra la pallina andrà da un'altra parte.