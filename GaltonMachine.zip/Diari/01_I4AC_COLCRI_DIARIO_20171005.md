##Diario Galton Machine Project

####Data : 05 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Risolto errore nello XAML della MainWindow, mi è bastato togliere il codice che avevo aggiunto nel file xaml.cs della view
- Continuata grafica, aggiunta grid, pallina, margini...


##Problemi riscontrati e soluzioni adottate

Nessun problema degno di nota

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

Aggiornare documentazione e Gantt, finire animazione pallina