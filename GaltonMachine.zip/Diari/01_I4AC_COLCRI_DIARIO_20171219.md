## Diario Galton Machine Project

#### Data : 19 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Finita gran parte della documentazione
- Aggiornato Gantt consuntivo
- Tentato di risolvere l'OverflowException

## Problemi riscontrati e soluzioni
\-
## Punto di situazione del lavoro

Leggermente indietro con la doc, OverflowException non ancora risolto

## Programma per la prossima volta

Finire la doc, iniziare il testing