## Diario Galton Machine Project

#### Data : 20 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Quasi finita doc, mancano di finire i testcase, costi e sitografia

## Problemi riscontrati e soluzioni

Ho tentato di far passare il riferimento all'immagine della curva piuttosto che copiarla ma continuava a dare errore di "dipendenza" (significa che bisognerebbe usare il dispatcher) ma anche usando il dispatcher dava lo stesso errore.

## Punto di situazione del lavoro

Giusto giusto

## Programma per la prossima volta

Finire la doc, preparare il materiale da consegnare