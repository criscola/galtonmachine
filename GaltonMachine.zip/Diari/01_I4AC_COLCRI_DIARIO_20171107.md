##Diario Galton Machine Project

####Data : 7 novembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Continuato sistema di disegno degli istogrammi
- Modificata leggermente struttura classi

##Problemi riscontrati e soluzioni adottate

Nessun problema riscontrato

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

- Fare la scala degli istogrammi e aggiungere curva normale, documentazione