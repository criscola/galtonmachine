##Diario Galton Machine Project

####Data : 04 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Documentazione ItemsControl
- Parlato con coordinatore stage (circa 20 min, non inerente al lavoro ma indico che non ero presente per tot tempo alla lezione per tal motivo)
- Sistemato problema Width non perfetto dello UserControl settando una proprietà nella MainWindow (SizeToContent="Width") in modo da settare il width quanto la larghezza dei controlli e tolto designwidth e designheight dallo usercontrol

##Problemi riscontrati e soluzioni adottate

- Ho un "problema" nella MainWindow indica un errore alla linea 12 dove si dichiara lo usercontrol "Object not set to an instance of an object" comunque anche ricompilando funziona dunque vedrò la prossima volta la soluzione anche se effettivamente non è un grosso problema

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

Continuare a lavorare sulla grafica, aggiungere la pallina, evt. aggiungere grandezze elementi dinamici