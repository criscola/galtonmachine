##Diario Galton Machine Project

####Data : 28 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Corretto definitivamente il codice di disegno su JavaFX che verrà traslato su C# in un secondo momento
- Continuata strutturazione del progetto usando il pattern MVVM
- Discusso con il docente responsabile del progetto e raccolto informazioni utili per sbloccarmi dai problemi riscontrati in settimana

##Problemi riscontrati e soluzioni adottate
-

##Punto di situazione del lavoro

Leggermente indietro 

##Programma per la prossima volta

- Finire MVVM con animazioni, trasporre codice di disegno in C#