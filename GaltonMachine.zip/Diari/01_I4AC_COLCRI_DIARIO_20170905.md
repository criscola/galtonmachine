##Diario Galton Machine Project

####Data : 05 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Continuato Gantt
- Analisi requisiti
- Analisi del dominio
- Abstract e scopo
- Formattazione doc
- Iniziato Gantt consuntivo

##Problemi riscontrati e soluzioni adottate

-

##Punto di situazione del lavoro

In linea.

##Programma per la prossima volta

- Continuare Gantt
- Continuare analisi Velcro Physics + WPF
- Aggiungere dettagli analisi dei requisiti se possibile