##Diario Galton Machine Project

####Data : 25 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Modificata architettura classi
- Continuato algoritmo per disegnare gli istogrammi

##Problemi riscontrati e soluzioni adottate

- Ho avuto un problema di NullPointerException, ma infine ho capito che avevo messo una chiamata a un metodo in una proprietà a cui accedevo prima dell'istanza dell'oggetto chiamato nel metodo, ho risolto usando l'operatore null-conditional (?) nella proprietà. 

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

- Continuare con gli istogrammi