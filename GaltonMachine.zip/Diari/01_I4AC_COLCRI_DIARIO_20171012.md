##Diario Galton Machine Project

####Data : 12 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Aggiornata documentazione
- Codice per i comandi
- Modificato disposizione elementi grafici
- Aggiornata pulizia codice

##Problemi riscontrati e soluzioni adottate

Nessun problema degno di nota riscontrato (a parte i bottoni che appaiono sopra il canvas nonostante abbia specificato che il canvas è alto tot.)

##Punto di situazione del lavoro

Leggermente indietro

##Programma per la prossima volta

- Continuare i comandi e aggiustare la grafica