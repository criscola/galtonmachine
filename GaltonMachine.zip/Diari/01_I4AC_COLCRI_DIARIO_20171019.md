##Diario Galton Machine Project

####Data : 19 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Terminati controlli
- Corretto il thread
- Ricerca della libreria per fare grafici
- Refactoring

##Problemi riscontrati e soluzioni adottate

Nessun problema

##Punto di situazione del lavoro

In linea

##Programma per la prossima volta

- Istrogrammi, finire textblock nella gui