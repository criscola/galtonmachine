## Diario Galton Machine Project

#### Data : 22 novembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Continuati lavori su curva normale

Sono andato avanti a cercare di capire come implementare la curva normale. Ho aggiunto una funzionalità che rende negativa la media se i dati sono distribuiti più sulla sinistra della curva o mette la media a 0 in caso sono distribuiti uniformemente. Il prossimo passo è quello di capire come gestire l'ampiezza verticale della curva perchè con l'aumentare dei dati vi è un restringimento verticale che sballa la rappresentazione, probabilmente è necessario standardizzare i dati prima di rappresentarli graficamente Z = X - μ / σ. Domani parlerò con la soressa di matematica per cercare informazioni supplementari. Inoltre stavo cercando di creare una curva di Bezier prendendo i dati degli istogrammi e utilizzando la scala già esistente per creare una sorta di confronto fra una distribuzione normale ideale e, appunto, la curva di Bezier (che rappresenterebbe la distribuzione effettiva dei dati).

- Scritti due capitoletti nella progettazione in merito a istogrammi e curva

## Problemi riscontrati e soluzioni

\-

## Punto di situazione del lavoro

Un po' indietro con la curva 

## Programma per la prossima volta

Continuare con la curva
