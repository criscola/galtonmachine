## Diario Galton Machine Project

#### Data : 07 dicembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Refactoring codice

## Problemi riscontrati e soluzioni

- Non si vedono ancora gli istogrammi

## Punto di situazione del lavoro

Indietro

## Programma per la prossima volta

Continuare riscrittura codice