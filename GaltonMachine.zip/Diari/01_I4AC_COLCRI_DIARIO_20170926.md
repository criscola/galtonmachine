##Diario Galton Machine Project

####Data : 26 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Continuata documentazione
- Lavorato sul progetto console e su quello WPF con scarsi risultati

##Problemi riscontrati e soluzioni adottate

- Ho cercato di far funzionare il binding per poter muovere la pallina ma non ha funzionato. 

##Punto di situazione del lavoro

Leggermente indietro per via della gita

##Programma per la prossima volta

- Continuare a lavorare sull'implementazione in WPF e cercare far funzionare il disegno del tutto, unire la logica (dal progetto console) alla grafica