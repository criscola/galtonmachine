## Diario Galton Machine Project

#### Data : 23 novembre 2017 
#### Autore : Cristiano Colangelo
#### Luogo: SAM Trevano

## Lavori svolti

- Continuati lavori su curva normale

Sono andato avanti a cercare di risolvere il problema della curva che continua a restringersi verticalmente. Assieme con la docente di matematica abbiamo provato a vedere sul mezzogiorno il problema ma non siamo riusciti a trovare una soluzione definitiva, mi ha comunque fatto vedere un'altra rappresentazione chiamata boxplot che potrebbe eventualmente essere integrata nel progetto come alternativa/aggiunta. Quando le ho parlato dell'opzione di riscalare gli assi mi ha  detto che forse sto cercando di forzare la curva a fare ciò che voglia io piuttosto ciò che dovrebbe fare veramente. Ho inoltre cercato supporto col docente responsabile e lui mi ha detto che c'è un problema nel mio codice in quanto la curva normale non dovrebbe avere questo comportamento anomalo. Abbiamo anche fatto entrambi una simulazione excel per capire vedere effettivamente il comportamento della curva e ha confermato il problema al mio codice. Infine il docente mi ha spiegato di moltiplicare i valori prima di buttarli nei calcoli.

## Problemi riscontrati e soluzioni

\-

## Punto di situazione del lavoro

Un po' indietro con la curva 

## Programma per la prossima volta

Continuare la curva
