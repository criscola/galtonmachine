##Diario Galton Machine Project

####Data : 13 settembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Stesura struttura progetto MVVM 
- Diagrammi concettuali implementazione
- Studio del pattern MVVM

##Problemi riscontrati e soluzioni adottate

-

##Punto di situazione del lavoro

In linea

##Programma per la prossima volta

- Continuare a scrivere la logica del programma 
- Cercare di continuare l'implementazione di MVVM
- Continuare a disegnare schemi per la documentazione di implementazione