##Diario Galton Machine Project

####Data : 14 novembre 2017 <br> Autore : Cristiano Colangelo <br> Luogo: SAM Trevano

##Lavori svolti

- Finiti istogrammi con etichette
- Sistemato un bug nella generazione delle griglia (generavo un elemento in più)
- Pulizia codice
- Aggiornato Gantt
- Continuato sistema disegno curva normale

##Problemi riscontrati e soluzioni

Ho avuto un problema perchè generando le etichette degli istogrammi mi generava un elemento in più, ho risolto vedendo che avevo un for nella classe QuincunxGrid con una condizione di uscita sbagliata.

##Punto di situazione del lavoro

Se finisco questa settimana la curva normale e possibilmente la scala del grafico dovrei essere a buon punto. Finito con questo dovrò pensare al sistema di report.

##Programma per la prossima volta

Finire la generazione della curva normale.